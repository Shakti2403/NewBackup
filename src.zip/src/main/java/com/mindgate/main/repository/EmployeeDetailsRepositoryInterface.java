package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.JobRequest;

public interface EmployeeDetailsRepositoryInterface {

	
	public  EmployeeDetails getByLoginId(int employeeId);
	
   public List<EmployeeDetails> getAllEmployeeDetailsByProjectId(int projectId);
   
   public List<EmployeeDetails> getAllEmployeeDetailsByJobId(int jobId);
   
   public boolean updateEmployeeDetailsAssign(EmployeeDetails employeeDetails);
   
}
 