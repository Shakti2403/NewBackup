
package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.DocumentDetails;
import com.mindgate.main.domain.JobRequest;

public class ApplicantDetailsRowMapper implements RowMapper<ApplicantDetails> {

	@Override
	public ApplicantDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		int applicantId = rs.getInt("applicant_id");
		String applicantName = rs.getString("applicant_name");
		String mailId = rs.getString("mail_id");
		String contactNumber = rs.getString("contact_number");
		String skill1 = rs.getString("skill_1");
		String skill2 = rs.getString("skill_2");
		String skill3 = rs.getString("skill_3");
		String qualification = rs.getString("qualification");
		String experience = rs.getString("experience");
		String status = rs.getString("status");
		int jobId = rs.getInt("job_id");
		int documentId = rs.getInt("document_id");
		
		DocumentDetails documentDetails = new DocumentDetails();
		documentDetails.setDocumentId(documentId);
		
		System.out.println(documentDetails);
		
		JobRequest jobRequest = new JobRequest();
		jobRequest.setJobId(jobId);
		
		System.out.println(jobRequest);
		
		ApplicantDetails applicantDetails= new ApplicantDetails(applicantId, applicantName, mailId, contactNumber, skill1, skill2, skill3, qualification, experience, status, jobId, documentId);
		System.out.println(applicantDetails);
		return applicantDetails;
		
		
		
	}

}
