package com.mindgate.main.domain;

import java.sql.Blob;
import java.util.Objects;

public class DocumentDetails {

	private int documentId;
	private String documentName;
	private String documentType;
	private Blob document;
	
	public DocumentDetails() {
		// TODO Auto-generated constructor stub
	}

	public DocumentDetails(int documentId, String documentName, String documentType, Blob document) {
		super();
		this.documentId = documentId;
		this.documentName = documentName;
		this.documentType = documentType;
		this.document = document;
	}

	public int getDocumentId() {
		return documentId;
	}

	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public Blob getDocument() {
		return document;
	}

	public void setDocument(Blob document) {
		this.document = document;
	}

	@Override
	public String toString() {
		return "DocumentDetails [documentId=" + documentId + ", documentName=" + documentName + ", documentType="
				+ documentType + ", document=" + document + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(document, documentId, documentName, documentType);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocumentDetails other = (DocumentDetails) obj;
		return Objects.equals(document, other.document) && documentId == other.documentId
				&& Objects.equals(documentName, other.documentName) && Objects.equals(documentType, other.documentType);
	}
	
	
	
}
