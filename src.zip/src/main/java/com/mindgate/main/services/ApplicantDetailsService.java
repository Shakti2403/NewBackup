package com.mindgate.main.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.repository.ApplicantDetailsRepositoryInterface;

@Service
public class ApplicantDetailsService implements ApplicantDetailsServiceInterface {

	@Autowired
	private ApplicantDetailsRepositoryInterface applicantDetailsRepositoryInterface;
	
	
	@Override
	public List<ApplicantDetails> getAllAppicantDetails() {
		// TODO Auto-generated method stub
		return applicantDetailsRepositoryInterface.getAllAppicantDetails();
	}


	@Override
	public boolean addNewApplicantDetails(ApplicantDetails applicantDetails) {
		// TODO Auto-generated method stub
		return applicantDetailsRepositoryInterface.addNewApplicantDetails(applicantDetails);
	}


	@Override
	public boolean updateApplicantDetailsStatus(ApplicantDetails applicantDetails) {
		// TODO Auto-generated method stub
		return applicantDetailsRepositoryInterface.updateApplicantDetailsStatus(applicantDetails);
	}


	@Override
	public List<ApplicantDetails> getAllAppicantDetailsByStatus() {
		return applicantDetailsRepositoryInterface.getAllAppicantDetailsByStatus();
	}

}
